extend("fisktag:fisktag_base");
loadTextures({
    "base": "fisktag:gilly/scout",
    "lights": "fisktag:gilly/scout_lights",
    "lights_red": "fisktag:gilly/scout_lights_red",
    "lights_blue": "fisktag:gilly/scout_lights_blue",
    "boots": "fisktag:scout_boots",
    "boots_red": "fisktag:scout_boots_lights_red",
    "boots_blue": "fisktag:scout_boots_lights_blue",
    "boots_neutral": "fisktag:scout_boots_lights"
});

var utils = implement("fiskheroes:external/utils");
var body_lines = implement("fiskheroes:external/body_lines");

var boots;
var boot_model;

var shrink_lights;

function initEffects(renderer) {
    parent.initEffects(renderer);
    
    boot_model = renderer.createResource("MODEL", "fisktag:scout_boot");
    boot_model.generateMirror();
    boots = renderer.createEffect("fiskheroes:model");
    boots.setModel(boot_model);
    boots.anchor.set("rightLeg");
    boots.mirror = true;
    
    shrink_lights = body_lines.create(renderer, "fiskheroes:atom_shrink", 0x005EFF, [
        { anchor: "rightLeg", renderLayer: "HELMET", mirror: true, entries: [
            { "start": [0.0, 12.0, 1.0], "end": [0.0, 24.0, 1.0], "size": [2, 2] },
            { "start": [0.0, 12.0, -1.5], "end": [0.0, 24.0, -1.5], "size": [1, 2] },

            { "start": [-1.7, 8.7, 2.7], "end": [-1.75, 17.0, 5.5], "size": [2, 1] },
            { "start": [1.7, 8.7, 2.7], "end": [1.75, 17.0, 5.5], "size": [2, 1] }
        ]}
    ]);
    
    utils.bindParticles(renderer, "fisktag:scout_leap").setCondition(entity => entity.getData("fisktag:dyn/leap_cooldown") > 0.75);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "scout.ROLL", "fiskheroes:falcon_dive_roll")
        .setData((entity, data) => {
            var f = entity.getInterpolatedData("fisktag:dyn/leap_cooldown");
            data.load(f > 0 ? Math.min((1 - f) * 2.5, 1) : 0);
        });
}

function teamColor(entity, redColor, blueColor) {
    var s = entity.team().name();
    return s == "fisktag_RED" ? redColor : s == "fisktag_BLUE" ? blueColor : 0xFFFFFF;
}

function render(entity, renderLayer, isFirstPersonArm) {
    switch (entity.team().name()) {
        case "fisktag_RED":
            boot_model.texture.set("boots", "boots_red");
            break;
        case "fisktag_BLUE":
            boot_model.texture.set("boots", "boots_blue");
            break;
        default:
            boot_model.texture.set("boots", "boots_neutral");
            break;
    }
    if (!isFirstPersonArm) {
        boots.render();

        var f = entity.getInterpolatedData("fisktag:dyn/leap_cooldown");
        if (f > 0) {
            var color = teamColor(entity, 0xFF1100, 0x0011FF);
            shrink_lights.effects.forEach(effect => {
                effect.effect.color.set(color);
            });

            f = 1 - Math.min((1 - f) * 2.5, 1);
            shrink_lights.opacity = 0.5 - Math.cos(2 * Math.PI * f * f) / 2;
            shrink_lights.progress = shrink_lights.opacity;
            shrink_lights.render(renderLayer);
        }
    }
}
