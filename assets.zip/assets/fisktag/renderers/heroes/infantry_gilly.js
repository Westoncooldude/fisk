extend("fisktag:infantry");
loadTextures({
    "base": "fisktag:gilly/infantry",
    "lights": "fisktag:gilly/infantry_lights",
    "lights_red": "fisktag:gilly/infantry_lights_red",
    "lights_blue": "fisktag:gilly/infantry_lights_blue"
});
