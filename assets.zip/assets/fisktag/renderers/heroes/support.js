extend("fisktag:fisktag_base");
loadTextures({
    "base": "fisktag:support",
    "lights": "fisktag:support_lights",
    "lights_red": "fisktag:support_lights_red",
    "lights_blue": "fisktag:support_lights_blue"
});
