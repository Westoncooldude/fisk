extend("fisktag:fisktag_base");
loadTextures({
    "base": "fisktag:tank",
    "lights": "fisktag:tank_lights",
    "lights_red": "fisktag:tank_lights_red",
    "lights_blue": "fisktag:tank_lights_blue",
    "chest": "fisktag:tank_chest",
    "chest_red": "fisktag:tank_chest_lights_red",
    "chest_blue": "fisktag:tank_chest_lights_blue",
    "chest_neutral": "fisktag:tank_chest_lights"
});

var chest;
var chest_model;

function initEffects(renderer) {
    parent.initEffects(renderer);
    chest_model = renderer.createResource("MODEL", "fisktag:tank_chest");
    chest = renderer.createEffect("fiskheroes:model");
    chest.setModel(chest_model);
    chest.anchor.set("body");
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (!isFirstPersonArm) {
        switch (entity.team().name()) {
            case "fisktag_RED":
                chest_model.texture.set("chest", "chest_red");
                break;
            case "fisktag_BLUE":
                chest_model.texture.set("chest", "chest_blue");
                break;
            default:
                chest_model.texture.set("chest", "chest_neutral");
                break;
        }
        chest.render();
    }
}
