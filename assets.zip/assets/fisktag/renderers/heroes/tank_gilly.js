extend("fisktag:fisktag_base");
loadTextures({
    "base": "fisktag:gilly/tank",
    "lights": "fisktag:gilly/tank_lights",
    "lights_red": "fisktag:gilly/tank_lights_red",
    "lights_blue": "fisktag:gilly/tank_lights_blue"
});
