extend("fiskheroes:hero_basic");

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => "base");
    renderer.setLights((entity, renderLayer) => {
        switch (entity.team().name()) {
            case "fisktag_RED":
                return "lights_red";
            case "fisktag_BLUE":
                return "lights_blue";
            default:
                return "lights";
        }
    });
    
    renderer.showModel("HELMET", "head", "headwear", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
    renderer.fixHatLayer("HELMET");
}

function initEffects(renderer) {
    var forcefield = renderer.bindProperty("fiskheroes:forcefield");
    forcefield.setShape(36, 18).setOffset(0.0, 7.0, 0.0).setScale(0.9, 1.15, 0.9);
    forcefield.setCondition(entity => {
        if (!entity.isInvulnerable()) {
            return false;
        }

        var f = entity.loop(80);
        forcefield.color.setHSB(entity.loop(10), 0.25 + 0.1 * sinusoid(2 * f), 1);
        forcefield.opacity = sinusoid(8 * f) * 0.05 + sinusoid(2 * f) * 0.1;
        return true;
    });
}

function sinusoid(x) {
    return 0.5 - Math.cos(x * Math.PI) / 2;
}

function getColor(entity) {
    var t = entity.team().name();
    return t === "fisktag_RED" ? 0xFF1100 : t === "fisktag_BLUE" ? 0x0011FF : 0xFFFFFF;
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
}
