extend("fisktag:fisktag_base");
loadTextures({
    "base": "fisktag:infantry",
    "lights": "fisktag:infantry_lights",
    "lights_red": "fisktag:infantry_lights_red",
    "lights_blue": "fisktag:infantry_lights_blue"
});

function initEffects(renderer) {
    parent.initEffects(renderer);

    var forcefield = renderer.bindProperty("fiskheroes:forcefield");
    forcefield.setShape(36, 18).setOffset(0.0, 7.0, 0.0);
    forcefield.setCondition(entity => {
        var f = entity.getInterpolatedData("fisktag:dyn/armor_timer");
        var f1 = easeOutElastic(f);
        forcefield.color.set(getColor(entity));
        forcefield.opacity = easeOutBounce(f) * 0.15;
        forcefield.setScale(0.9 * f1, 1.15 * f1, 0.9 * f1);
        return true;
    });
}

function easeOutBounce(x) {
    var n1 = 7.5625;
    var d1 = 2.75;
    
    if (x < 1 / d1) {
        return n1 * x * x;
    } else if (x < 2 / d1) {
        return n1 * (x -= 1.5 / d1) * x + 0.75;
    } else if (x < 2.5 / d1) {
        return n1 * (x -= 2.25 / d1) * x + 0.9375;
    } else {
        return n1 * (x -= 2.625 / d1) * x + 0.984375;
    }
}

function easeOutElastic(x) {
    var c4 = (2 * Math.PI) / 3;
    return x === 0
      ? 0
      : x === 1
      ? 1
      : Math.pow(2, -10 * x) * Math.sin((x * 10 - 0.75) * c4) + 1;
}
