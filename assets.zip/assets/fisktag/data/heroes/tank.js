function init(hero) {
    hero.setName("class.fisktag.tank.name");
    hero.setTier(1);
    hero.hide();

    hero.setHelmet("item.superhero_armor.piece.helmet");

    hero.addAttribute("FISKTAG_HEALTH", 4, 0);
    hero.addAttribute("FISKTAG_ARMOR", 1, 0);
    hero.addAttribute("FALL_RESISTANCE", 1.0, 1);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);

    hero.setDefaultScale(1.1);
    hero.setHasPermission((entity, permission) => permission === "USE_FISKTAG_GUN");
    hero.supplyFunction("canAim", entity => entity.getHeldItem().name() === "fisktag:weapon");
}
