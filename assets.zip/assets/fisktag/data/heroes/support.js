function init(hero) {
    hero.setName("class.fisktag.support.name");
    hero.setTier(1);
    hero.hide();

    hero.setHelmet("item.superhero_armor.piece.helmet");

    hero.addPowers("fisktag:support");
    hero.addAttribute("FISKTAG_HEALTH", 3, 0);
    hero.addAttribute("FALL_RESISTANCE", 10.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.2, 1);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    
    hero.setModifierEnabled((entity, modifier) => entity.getHeldItem().isEmpty());
    hero.setHasPermission((entity, permission) => permission === "USE_FISKTAG_GUN");
    hero.supplyFunction("canAim", entity => entity.getHeldItem().name() === "fisktag:weapon");
    hero.supplyFunction("fisktagScroll", true);
    hero.supplyFunction("fisktag:getAbilities", {
        "abilities": [
            {
                "input": {
                    "key": "key.use",
                    "name": "key.fisktagShield",
                    "isVisible": "entity.getHeldItem().isEmpty()"
                },
                "cooldownData": {
                    "cooldown": "FISKTAG_SHIELD"
                }
            }
        ]
    });
}
